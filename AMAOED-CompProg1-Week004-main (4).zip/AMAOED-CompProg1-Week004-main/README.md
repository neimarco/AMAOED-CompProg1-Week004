# AMAOED-CompProg1-Week004
My very first C++ application
